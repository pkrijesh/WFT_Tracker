var express =require('express');
var mongoose=require('mongoose');
var bodyParser=require('body-parser');
var cors=require('cors');
var path=require('path');
var http=require('http');
const hostname='192.168.0.104';//'192.168.43.89';
var app=express();
var api =require('./routes/route');

//connect to mongodb

mongoose.connect('mongodb://192.168.0.104:27017/mean');
//mongoose.connect('mongodb://192.168.43.89:27017/mean');
//mongoose.connect('mongodb://10.102.139.60:27017/mean');
//on connection
mongoose.connection.on('connected',()=>{
    console.log('conected to the mongodb database over27017');
});
mongoose.connection.on('error',(err)=>{
    if(err)
    {
        return console.log('Error in database connection: '+err);
    }
});

//adding middle ware
app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

app.use(express.static(path.join(__dirname,'dist')));

app.use('/',api);


app.get('/*', function(req, res) {
  res.sendFile(path.join(__dirname + '/dist/index.html'));
  });
var port=process.env.PORT || '3000';
//app.set('port',port);

var server=http.createServer(app);
console.log(server);
server.listen(port,hostname,()=>console.log("server is running....."));
/*const server = http.createServer((req, res) => {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.end('Hello hai ... bye\n');
  });

  server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });*/
