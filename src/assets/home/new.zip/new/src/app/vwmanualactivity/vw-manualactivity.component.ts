import { ManualModel } from './../Mactivity';
import { Component, OnInit, Input } from '@angular/core';
import {ManualService} from '../ManualService';
declare const $;

@Component({
  selector: 'vwmanualactivity',
  templateUrl: './vw-manualactivity.component.html',
  styleUrls: ['./vw-manualactivity.component.css'],
  providers:[ManualService]
})
export class VwManualactivityComponent implements OnInit {
  contacts: ManualModel[];
  keys: String[];
  contact: ManualModel;
manualname: string;
manualstatus: string;
manualtarget:string;

@Input() appRef: string;
// @Input() manual: ManualModel;

  constructor(private manualService: ManualService) {

    this.getManualContact();
  }


    /*addamsContact(){
  const newamsContact={
    app_id:this.app_id,
    app_name:this.app_name,
    app_owner:this.app_owner,
    app_contact:this.app_contact
  }
  this.amsContactService.addAmsContact(newamsContact)
  .subscribe(contact=>{
    this.contacts.push(contact);
    this.amsContactService.getamsContact()
    .subscribe(contacts=>this.contacts=contacts);
    this.app_id="";
    this.app_name="";
    this.app_owner="";
    this.app_contact="";
  });
} */

getManualContact() {
  console.log('get');
  this.manualService.getManualContact()
  .subscribe(contacts => this.contacts = contacts);
}
addManual(value) {
    const newManual = {
      manualname: this.manualname,
      manualstatus: this.manualstatus,
      manualtarget: this.manualtarget,
      appRef: this.appRef
  };
// const manual = new ManualModel ( value, 'ABi');
console.log(newManual);
    this.manualService.addManualService(newManual)
    .subscribe(response => {
      console.log(response);
        this.manualname = '';
      this.manualstatus = '';
    this.manualtarget = ''; }
      );
    }


ngOnInit() {
    $(function () {
      $('#vwmanual-activity').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'print'
        ]
    } );
    });
  }

}
