import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import {ManualModel} from '../app/Mactivity';
import 'rxjs/add/operator/map';

@Injectable()
export class ManualService {

  constructor(private http: Http) { }

  addManualService(newManualActivity){
    const headers = new Headers();
    headers.append('Content-Type','application/json');
    return this.http.post('http://192.168.43.89:3000/singleapp', newManualActivity, {headers: headers})
    .map(res=>res.json());
  }
  getManualContact() {
    return this.http.get('http://192.168.43.89:3000/singleapp')
    .map(res => res.json());
  }

}
