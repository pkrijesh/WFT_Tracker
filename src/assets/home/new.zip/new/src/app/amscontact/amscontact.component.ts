import { Component, OnInit } from '@angular/core';
import{AmscontactService} from '../amscontact.service';
import{amscontact} from '../amscontact';

@Component({
  selector: 'amscontact',
  templateUrl: './amscontact.component.html',
  styleUrls: ['./amscontact.component.css']
})
export class AmscontactComponent implements OnInit {
  contacts:amscontact[];
  keys: String[];
  contact:amscontact;
  app_id:string;
  app_name:string;
  app_owner:string;
  app_contact:string;
  platform_name:string;
  wipro_lead:string;
  wipro_pm:string;
  selectedItem:amscontact;
  toggleForm:boolean = false;

  appNames = [
    { id: 1, name: 'ITA'} ,
    { id: 2, name: 'UFO'} ,
    { id: 3, name: 'Phoenix'}
  ];
  constructor(private amsContactService: AmscontactService) { }

addamsContact(){
  const newamsContact={
    app_id:this.app_id,
    app_name:this.app_name,
    app_owner:this.app_owner,
    app_contact:this.app_contact,
    platform_name:this.platform_name,
    wipro_lead:this.wipro_lead,
    wipro_pm:this.wipro_pm
  }
  this.amsContactService.addAmsContact(newamsContact)
  .subscribe(contact=>{
    this.contacts.push(contact);
    this.amsContactService.getamsContact()
    .subscribe(contacts=>this.contacts=contacts);
    this.app_id="";
    this.app_name="";
    this.app_owner="";
    this.app_contact="";
    this.platform_name="";
    this.wipro_lead="";
    this.wipro_pm="";
  });
}

deleteamsContact(id:any){
  var contacts=this.contacts;
  this.amsContactService.deleteAmsContact(id)
  .subscribe(data=>{
    if(data.n==1){
      console.log("before splice")
      for(var i=0;i<contacts.length;i++){
        if(contacts[i]._id==id){
          console.log("id matched");
          contacts.splice(i,1);
        }
      }
    }
  })
}
getContact()
{
  console.log("get");
  this.amsContactService.getamsContact()
  .subscribe(contacts => this.contacts=contacts);
}
//Edits
editContact(form)
{
  console.log("Inside edit function");
  let newContact:amscontact={
    _id:this.selectedItem._id,
    //need to change
    app_id:form.value.app_id,
    app_name:form.value.app_name,
    app_owner:form.value.app_owner,
    app_contact:form.value.app_contact,
    platform_name:form.value.platform_name,
    wipro_lead:form.value.wipro_lead,
    wipro_pm:form.value.wipro_pm
      }
      this.amsContactService.updateContact(newContact)
      .subscribe(contact => {
        console.log("value is getting updated");
        this.getContact();
       });
       this.toggleForm=!this.toggleForm;
}
showUpdateForm(contact)
{
  this.selectedItem=contact;
  this.toggleForm=!this.toggleForm;
}
cancel(){
  this.toggleForm=!this.toggleForm;
}

  ngOnInit() {
   this.amsContactService.getamsContact()
   .subscribe(contacts=>{
    this.contacts=contacts;
    this.keys = Object.keys(this.contacts);
    console.log(this.contacts);

   // Object.keys(contacts);

  });

  }

}
