import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cloudapps',
  templateUrl: './cloud-apps.component.html',
  styleUrls: ['./cloud-apps.component.css']
})
export class CloudAppsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}