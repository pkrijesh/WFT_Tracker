import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import{AmscontactService} from '../amscontact.service';
import{amscontact} from '../amscontact';
import { Http, Response } from '@angular/http';

@Component({
  selector: 'appdetils',
  templateUrl: './appdetails.component.html',
  styleUrls: ['./appdetails.component.css']
})
export class AppdetailsComponent implements OnInit {
  alldetails;
  manualactivity;
  appuid: String;

  selectedItem:amscontact;
  constructor(private route:ActivatedRoute,private amsContactService: AmscontactService) { }
  editContact(form){
    console.log(form.value.wipro_pm);
    let newContact:amscontact={
      _id:this.route.snapshot.paramMap.get('appuid'),
      //need to change
      app_id:form.value.app_id,
      app_name:form.value.app_name,
      app_owner:form.value.app_owner,
      app_contact:form.value.app_contact,
      platform_name:form.value.platform_name,
      wipro_lead:form.value.wipro_lead,
      wipro_pm:form.value.wipro_pm
        }
        this.amsContactService.updateContact(newContact)
        .subscribe(contact => {
          console.log("value is getting updated");

         });
  }

  ngOnInit() {
   this.appuid = this.route.snapshot.paramMap.get('appuid');
   console.log(this.appuid);
   this.amsContactService.getoneamscontact(this.appuid)
   .subscribe(alldetails=>{
    this.alldetails=alldetails;
    this.manualactivity=this.alldetails.manualActivity;
    console.log(this.manualactivity);

  });
  }

}

