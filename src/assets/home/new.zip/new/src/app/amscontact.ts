export class amscontact{
    _id?: string;
    app_id: string;
    app_name:string;
    platform_name:string;
    app_owner:string;
    app_contact:string;
    wipro_lead:string;
    wipro_pm:string;
}