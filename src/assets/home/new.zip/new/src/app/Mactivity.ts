export class  ManualModel {
  manualname: string;
  manualstatus: string;
  manualId?: string;
  appRef?: string;
  manualtarget: string;
  constructor(  ) {
  }
}
