export class User {
  constructor(email: string,
    password:string){

    }
}
