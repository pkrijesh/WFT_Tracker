const mongoose=require('mongoose');
//const Manual=require('./manual');
var ContactShema =mongoose.Schema;
//var ManualSchema =mongoose.Schema;
//const ManualModel = new Manual;

/*var Manual= new mongoose.Schema({
  manualname:String,
  manualstatus:String
  });*/

var Contact= new ContactShema({
    app_id: {
        type: String,
        //required:true
    },
    app_name:{
        type: String,
       // required:true
    },
    app_owner:{
        type: String,
        //required:true
    },
    app_contact:{
        type: String,
        //required:true
    } ,
    platform_name:{
        type: String,
        //required:true
    } ,
    wipro_lead:{
        type: String,
        //required:true
    } ,
    wipro_pm:{
        type: String,
        //required:true
    }
});
//module.exports=mongoose.model('Manual',Manual);
module.exports=mongoose.model('Contact',Contact);
