const mongoose=require('mongoose');
const ManualSchema =mongoose.Schema;
var Manual= new ManualSchema({
    manualname: {
        type: String,

    },
    manualstatus:{
        type: String,

    },
    manualtarget:{
      type: String,
    },
    appRef:{
      type: String
    }
    //appRef:{ type: ManualSchema.Types.ObjectId,ref:'Appdetail'}
});

module.exports=mongoose.model('Mactivity',Manual);































/*//mosh
const mongoose=require('mongoose');
/*const ManualShema =mongoose.Schema;
var manual= new ManualShema({
    mactivity: {
        type: String,

    },
    status:{
        type: String,

    }
});

const ManualSchema = new mongoose.Schema({
  manualname:String,
  manualstatus:String
  });

module.exports=mongoose.model('Mactivity',ManualSchema);
//mosh */
