var mongoose = require('mongoose');
var router=express.Router();

// Define your schema as normal.
var userSchema = mongoose.Schema({
    email: { type: String, required: true },
    password: { type: String, required: true }
});
const user=module.exports=mongoose.model('users',userSchema);

