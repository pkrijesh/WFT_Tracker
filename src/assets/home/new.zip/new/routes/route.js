const express=require('express');
var router=express.Router();
const Contact=require('../model/amscontact');
const Manual=require('../model/manual');

router.get('/rakesh',(req,res,next)=>{
  //get contact
  Contact.find(function(err,result){
      res.json(result);
  });
});
//get allcontacts
router.get('/users',(req,res,next)=>{
    //get contact
    Contact.find(function(err,contacts){
        res.json(contacts);
    });
});

//get a single contact
router.get('/users/:id',(req,res,next)=>{
    Contact.find({_id:req.params.id},
    function(err,result){
        if(err){
            res.json(err);
        }
        else
        {
            res.json(result);
        }
    });
});


//add contact
router.post('/users',(req,res,next)=>{
    //add logic
    let newContact = new Contact({
        app_id: req.body.app_id,
        app_name: req.body.app_name,
        app_owner: req.body.app_owner,
        app_contact: req.body.app_contact,
        platform_name: req.body.platform_name,
        wipro_lead: req.body.wipro_lead,
        wipro_pm: req.body.wipro_pm
    });
    newContact.save((err,contact)=>{
        if(err){
            res.json({msg:'Failed to add contact'})
        }
        else{
            res.json({msg:'Successfully added contact'})
        }
    });
});

//updating the data
router.put('/users/:id',(req,res,next)=>{
    Contact.findOneAndUpdate({_id:req.params.id},{
        $set:{
            app_id: req.body.app_id,
            app_name: req.body.app_name,
            app_owner: req.body.app_owner,
            app_contact: req.body.app_contact,
            platform_name: req.body.platform_name,
            wipro_lead: req.body.wipro_lead,
            wipro_pm: req.body.wipro_pm
        }
    },
    function(err,result){
        if(err){
            res.json(err);
        }
        else
        {
            res.json(result);
        }
    });
});

//delete contact
router.delete('/users/:id',(req,res,next)=>{
    Contact.remove({_id: req.params.id},(err,result)=>{
        if(err){
            res.json(err);
        }
        else{
            res.json(result);
        }
    });
});
//add Manual activity -Mosh
router.post('/singleapp',(req,res,next)=>{
  //add logic
  let newactivity = new Manual({
    manualname : req.body.manualname,
    manualstatus : req.body.manualstatus,
    manualtarget : req.body.manualtarget,
    appRef: req.body.appRef
  }
  );
  console.log(newactivity);
  newactivity.save((err,contact)=>{
      if(err){
          res.json(err)
      }
      else{

          res.json({err})
      }
  });
});
router.get('/singleapp',(req,res,next)=>{
  //get contact
  Manual.find(function(err,result){
      res.json(result);
  });
});
module.exports=router;
